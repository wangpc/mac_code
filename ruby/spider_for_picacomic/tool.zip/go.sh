#!/bin/sh
nohup ruby ./get.rb > log &
